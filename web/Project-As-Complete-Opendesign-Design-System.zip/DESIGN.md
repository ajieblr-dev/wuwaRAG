# Project As Complete Opendesign Design System

> Category: Project Design System
> Surface: web

Created from OpenDesign project "opendesign-wuwa-lore-rag-prompt.md" (590e3270-e9c2-4fb0-9b28-2b9e59e9fdc4).

## 1. Visual Theme & Atmosphere

Describe the visual mood, product context, and the feeling this system should create.

Source context: Company/product context: Created from OpenDesign project "opendesign-wuwa-lore-rag-prompt.md" (590e3270-e9c2-4fb0-9b28-2b9e59e9fdc4). Additional notes: Created from OpenDesign project "opendesign-wuwa-lore-rag-prompt.md" (590e3270-e9c2-4fb0-9b28-2b9e59e9fdc4). Created from OpenDesign project "opendesign-wuwa-lore-rag-prompt.md" (590e3270-e9c2-4fb0-9b28-2b9e59e9fdc4).

## 2. Color

List brand colors, semantic roles, background surfaces, text colors, borders, and states.

## 3. Typography

Define display, heading, body, caption, and code typography. Include fallback stacks.

## 4. Spacing

Define the spacing scale, density, radius, and layout rhythm.

## 5. Layout & Composition

Describe grids, page structure, information density, navigation, and responsive behavior.

## 6. Components

Document buttons, cards, forms, tables, navigation, modals, and product-specific components.

## 7. Motion & Interaction

Define hover, focus, loading, transition, and reduced-motion behavior.

## 8. Voice & Brand

Describe copy style, terminology, capitalization, and tone.

## 9. Anti-patterns

List visual and interaction choices the agent must avoid when generating with this system.
